#!/usr/bin/env bash
# Steps 4 and 5: streaming standby (port 5433) and replication monitoring
set -euo pipefail

# --- Primary: replication role and pg_hba entry ---
sudo -u postgres psql -c "CREATE ROLE replicator WITH REPLICATION LOGIN PASSWORD 'reppass';"
echo "host replication replicator 127.0.0.1/32 scram-sha-256" | sudo tee -a /etc/postgresql/16/main/pg_hba.conf
sudo systemctl reload postgresql

# --- Build the standby (-R writes standby.signal + primary_conninfo) ---
rm -rf ~/standby
PGPASSWORD=reppass pg_basebackup -h 127.0.0.1 -U replicator -D ~/standby -R -P
ls ~/standby | grep -E "standby.signal|postgresql.auto.conf"

cat > ~/standby/postgresql.conf <<'EOF'
port = 5433
listen_addresses = '127.0.0.1'
unix_socket_directories = '/tmp'
hot_standby = on
EOF
printf "local all all trust\nhost all all 127.0.0.1/32 scram-sha-256\n" > ~/standby/pg_hba.conf
touch ~/standby/pg_ident.conf

/usr/lib/postgresql/16/bin/pg_ctl -D ~/standby -l ~/standby.log start
sleep 3
tail -n 8 ~/standby.log

# --- Monitor from the primary ---
sudo -u postgres psql -P pager=off -c "SELECT application_name, state, pg_wal_lsn_diff(sent_lsn, replay_lsn) AS lag_bytes FROM pg_stat_replication;"

# --- Prove replication and read-only behaviour ---
sudo -u postgres psql -d bootcamp -c "INSERT INTO students (full_name, course) VALUES ('Test Replica','Networking');"
sleep 2
psql -h /tmp -p 5433 -U postgres -d bootcamp -P pager=off -c "SELECT pg_is_in_recovery();" -c "SELECT * FROM students;"
psql -h /tmp -p 5433 -U postgres -d bootcamp -c "DELETE FROM students;" || echo "Expected: standby is read-only"
