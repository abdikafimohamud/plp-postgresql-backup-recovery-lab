#!/usr/bin/env bash
# Step 2: enable WAL archiving and take a base backup
set -euo pipefail

sudo mkdir -p /var/lib/postgresql/wal_archive /var/lib/postgresql/backups
sudo chown postgres:postgres /var/lib/postgresql/wal_archive /var/lib/postgresql/backups
sudo chmod 700 /var/lib/postgresql/wal_archive /var/lib/postgresql/backups

sudo tee /etc/postgresql/16/main/conf.d/wal_archive.conf > /dev/null <<'EOF'
wal_level = replica
archive_mode = on
archive_command = 'test ! -f /var/lib/postgresql/wal_archive/%f && cp %p /var/lib/postgresql/wal_archive/%f'
EOF

sudo systemctl restart postgresql
sudo -u postgres psql -P pager=off -c "SHOW wal_level;" -c "SHOW archive_mode;" -c "SHOW archive_command;"

# Force a segment switch and confirm it is archived
sudo -u postgres psql -c "SELECT pg_switch_wal();"
sleep 5
sudo ls -l /var/lib/postgresql/wal_archive

# Base backup (tar, gzip, WAL streamed)
sudo -u postgres pg_basebackup -D /var/lib/postgresql/backups/base -Ft -z -Xs -P
sudo ls -lh /var/lib/postgresql/backups/base
