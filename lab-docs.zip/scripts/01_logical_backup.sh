#!/usr/bin/env bash
# Step 1: logical backup + verification restore
set -euo pipefail

mkdir -p ~/backups
sudo -u postgres pg_dump -Fc bootcamp -f /tmp/bootcamp.dump
sudo cp /tmp/bootcamp.dump ~/backups/bootcamp.dump
sudo chown "$USER":"$(id -gn)" ~/backups/bootcamp.dump
ls -lh ~/backups/bootcamp.dump

# Inspect the archive table of contents
pg_restore --list ~/backups/bootcamp.dump | head

# Restore into a scratch database (recreate it so the check starts clean)
sudo -u postgres dropdb --if-exists bootcamp_check
sudo -u postgres createdb bootcamp_check
sudo -u postgres pg_restore -d bootcamp_check /tmp/bootcamp.dump
sudo -u postgres psql -d bootcamp_check -P pager=off -c "SELECT count(*) FROM students;"
