#!/usr/bin/env bash
# Step 3: point-in-time recovery from the base backup + archived WAL.
# Usage: ./03_pitr_recovery.sh '2026-10-10 18:03:13.201895+03'
# The target MUST be a real timestamp (from SELECT now()) that lies inside
# the archived WAL range, otherwise recovery aborts with:
#   FATAL: recovery ended before configured recovery target was reached
set -euo pipefail

TARGET="${1:?usage: $0 'YYYY-MM-DD HH:MM:SS.ffffff+03'}"
PGDATA=/var/lib/postgresql/16/main
STAMP=$(date +%Y%m%d%H%M%S)

# 1. Stop the server
sudo systemctl stop postgresql

# 2. Keep the damaged cluster as a safety net (never delete first)
sudo mv "$PGDATA" "${PGDATA}_old_$STAMP"

# 3. Restore the base backup into a fresh data directory
sudo -u postgres mkdir -p "$PGDATA"
sudo chmod 700 "$PGDATA"
sudo -u postgres tar -xzf /var/lib/postgresql/backups/base/base.tar.gz -C "$PGDATA"
sudo -u postgres tar -xzf /var/lib/postgresql/backups/base/pg_wal.tar.gz -C "$PGDATA/pg_wal"

# 4. Recovery settings + recovery.signal
sudo tee /etc/postgresql/16/main/conf.d/recovery.conf > /dev/null <<EOF
restore_command = 'cp /var/lib/postgresql/wal_archive/%f %p'
recovery_target_time = '$TARGET'
recovery_target_timeline = 'current'
recovery_target_action = 'promote'
EOF
sudo -u postgres touch "$PGDATA/recovery.signal"

# 5. Start and verify
sudo systemctl start postgresql
sleep 8
sudo -u postgres psql -d bootcamp -P pager=off -c "SELECT count(*) FROM students;" -c "SELECT * FROM students;"
sudo tail -n 15 /var/log/postgresql/postgresql-16-main.log

# 6. Cleanup so the settings do not apply on later restarts
sudo rm /etc/postgresql/16/main/conf.d/recovery.conf
sudo systemctl restart postgresql
