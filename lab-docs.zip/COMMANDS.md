# Command Runbook: Backups, PITR and Replication (PostgreSQL 16 on Ubuntu 24.04 / WSL)

Every command below was run in this lab. Matching scripts are in `scripts/`, config in `config/`, and real console output in `logs/`.

## 0. Environment
```bash
sudo apt update
sudo apt install postgresql postgresql-client -y
sudo service postgresql start
sudo -u postgres createdb bootcamp
sudo -u postgres psql -d bootcamp -c "CREATE TABLE students (id SERIAL PRIMARY KEY, full_name VARCHAR(100) NOT NULL, course VARCHAR(100) NOT NULL);"
sudo -u postgres psql -d bootcamp -c "INSERT INTO students (full_name, course) VALUES ('Ahmed Ali','Information Technology'),('Fatuma Hassan','Computer Science'),('Mohamed Noor','Software Engineering');"
```

## 1. Logical backup and verification  (`scripts/01_logical_backup.sh`)
```bash
mkdir -p ~/backups
sudo -u postgres pg_dump -Fc bootcamp -f /tmp/bootcamp.dump      # custom, compressed, portable
sudo cp /tmp/bootcamp.dump ~/backups/ && sudo chown "$USER":"$(id -gn)" ~/backups/bootcamp.dump
pg_restore --list ~/backups/bootcamp.dump | head                 # proves the archive is readable
sudo -u postgres createdb bootcamp_check
sudo -u postgres pg_restore -d bootcamp_check /tmp/bootcamp.dump # proves it restores
sudo -u postgres psql -d bootcamp_check -c "SELECT count(*) FROM students;"
```
Note: a scratch DB left over from a previous run causes "already exists" errors. Drop and recreate it before verifying.

## 2. WAL archiving and base backup  (`scripts/02_wal_archiving_basebackup.sh`, `config/wal_archive.conf`)
```bash
sudo mkdir -p /var/lib/postgresql/wal_archive /var/lib/postgresql/backups
sudo chown postgres:postgres /var/lib/postgresql/wal_archive /var/lib/postgresql/backups
sudo chmod 700 /var/lib/postgresql/wal_archive /var/lib/postgresql/backups
# write config/wal_archive.conf to /etc/postgresql/16/main/conf.d/
sudo systemctl restart postgresql          # archive_mode and wal_level need a restart, not a reload
sudo -u postgres psql -c "SELECT pg_switch_wal();"
sudo -u postgres pg_basebackup -D /var/lib/postgresql/backups/base -Ft -z -Xs -P
```
Why not `~/backups/wal` as in the lab text: the `postgres` service user cannot write into a normal user's home directory, so archiving would fail silently.

## 3. Disaster and PITR  (`scripts/03_pitr_recovery.sh`, `config/recovery.conf`)
```bash
sudo -u postgres psql -d bootcamp -c "SELECT now();"        # record the target
sudo -u postgres psql -d bootcamp -c "DELETE FROM students;" # the disaster
sudo -u postgres psql -c "SELECT pg_switch_wal();"          # flush last WAL into the archive
sudo systemctl stop postgresql
sudo mv /var/lib/postgresql/16/main /var/lib/postgresql/16/main_old
sudo -u postgres mkdir -p /var/lib/postgresql/16/main && sudo chmod 700 /var/lib/postgresql/16/main
sudo -u postgres tar -xzf /var/lib/postgresql/backups/base/base.tar.gz -C /var/lib/postgresql/16/main
sudo -u postgres tar -xzf /var/lib/postgresql/backups/base/pg_wal.tar.gz -C /var/lib/postgresql/16/main/pg_wal
# write config/recovery.conf to /etc/postgresql/16/main/conf.d/ with YOUR now() value
sudo -u postgres touch /var/lib/postgresql/16/main/recovery.signal
sudo systemctl start postgresql
sudo -u postgres psql -d bootcamp -c "SELECT count(*) FROM students;"
sudo rm /etc/postgresql/16/main/conf.d/recovery.conf && sudo systemctl restart postgresql
```
Incident note: the first attempt failed with `recovery ended before configured recovery target was reached` because the target time (18:07:31) was later than the end of the archived WAL (18:03). Using the real `now()` value (18:03:13.201895+03) fixed it. See `logs/03_pitr_recovery.log`.

## 4. Streaming standby  (`scripts/04_standby_and_monitor.sh`, `config/pg_hba_replication.conf`, `config/standby_postgresql.conf`)
```bash
sudo -u postgres psql -c "CREATE ROLE replicator WITH REPLICATION LOGIN PASSWORD 'reppass';"
echo "host replication replicator 127.0.0.1/32 scram-sha-256" | sudo tee -a /etc/postgresql/16/main/pg_hba.conf
sudo systemctl reload postgresql
PGPASSWORD=reppass pg_basebackup -h 127.0.0.1 -U replicator -D ~/standby -R -P
# write config/standby_postgresql.conf to ~/standby/postgresql.conf (port 5433)
/usr/lib/postgresql/16/bin/pg_ctl -D ~/standby -l ~/standby.log start
```
`-R` creates `standby.signal` and `primary_conninfo`. Port 5433 avoids a clash with the primary on 5432. The password is a lab-only value; use a secret manager in production.

## 5. Monitoring
```bash
sudo -u postgres psql -c "SELECT application_name, state, pg_wal_lsn_diff(sent_lsn, replay_lsn) AS lag_bytes FROM pg_stat_replication;"
psql -h /tmp -p 5433 -U postgres -d bootcamp -c "SELECT pg_is_in_recovery();"   # t on a standby
```
Result: `state = streaming`, `lag_bytes = 0`; a DELETE on the standby is rejected as read-only.

## Troubleshooting summary
| Symptom | Cause | Fix |
|---|---|---|
| `psql: command not found` | client tools not installed | `sudo apt install postgresql postgresql-client` |
| `relation "students" already exists` on restore | scratch DB reused | `dropdb` then `createdb` before restoring |
| `recovery ended before configured recovery target` | target time after the last archived WAL | use the real `now()` captured before the DELETE |
| `cp: cannot stat ...00000002.history` | PostgreSQL probing for optional files | harmless |
| `invalid length of startup packet` | VS Code port probe on 5433 | harmless |

## Recovery safety rules
1. Never delete the damaged cluster first; move it aside.
2. Record `SELECT now()` before risky changes.
3. Run `pg_switch_wal()` so the latest WAL reaches the archive.
4. Remove the temporary recovery settings after success.
