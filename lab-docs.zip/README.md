# PostgreSQL Backup, PITR and Replication Lab

A disaster-recovery runbook for PostgreSQL 16 on Ubuntu 24.04 (WSL). Every step was executed and verified.

| # | Stage | Result |
|---|-------|--------|
| 1 | Logical backup (`pg_dump -Fc`) | Restored into `bootcamp_check`, 3 rows verified |
| 2 | WAL archiving and `pg_basebackup` | WAL segments archived, base backup taken |
| 3 | Point-in-time recovery | `DELETE` of 5 rows undone, recovery stopped before transaction 773 |
| 4 | Streaming standby (port 5433) | Standby in recovery, streaming from primary |
| 5 | Monitoring | `pg_stat_replication`: `streaming`, `lag_bytes = 0` |

## Repository layout
- `COMMANDS.md`: annotated command runbook with troubleshooting table
- `scripts/`: repeatable shell scripts for each stage
- `config/`: `wal_archive.conf`, `recovery.conf`, `pg_hba_replication.conf`, `standby_postgresql.conf`
- `logs/`: real console output from each stage, including the failed first recovery attempt

## Key lessons
- The recovery target time must lie inside the archived WAL range, or recovery fails.
- On Ubuntu, archive WAL to a `postgres`-owned directory, not the home folder.
- PostgreSQL 16 uses `recovery.signal` plus normal settings; a standalone `recovery.conf` is no longer read.
- Keep the damaged data directory (`main_old`) until recovery is verified.
- A standby is read-only: writes fail with `cannot execute DELETE in a read-only transaction`.
- Use `scram-sha-256` in `pg_hba.conf` on current Ubuntu instead of `md5`.
